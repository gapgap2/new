"""Experimental decoder/editor for the 14 supplied AGF v35 files.

Preserves unknown metadata and frame rectangles. Not a game compatibility claim.
Requires Pillow. Usage: python agf_tool.py extract INPUT OUTPUT
                       python agf_tool.py pack ORIGINAL PNG_DIRECTORY OUTPUT
"""
import argparse
import hashlib
import json
import struct
import zlib
from pathlib import Path
from PIL import Image


class AGF:
    def __init__(self, path):
        self.blob = Path(path).read_bytes()
        self.version, self.width, self.height, self.count = struct.unpack_from('<4I', self.blob)
        if self.version != 35 or not 0 < self.count <= 300:
            raise ValueError('Unsupported AGF header')
        self.payload_at = 2416 + self.count * 8 + 48
        self.prefix = self.blob[:self.payload_at]
        self.rects = [struct.unpack_from('<4H', self.blob, 2416 + i * 8) for i in range(self.count)]
        self.offsets = list(struct.unpack_from(f'<{self.count}I', self.blob, 1216))
        dec = zlib.decompressobj()
        self.raw = dec.decompress(self.blob[self.payload_at:]) + dec.flush()
        if not dec.eof or dec.unused_data:
            raise ValueError('Unexpected compressed stream boundary')
        if struct.unpack_from('<I', self.blob, self.payload_at - 4)[0] != len(self.blob) - self.payload_at:
            raise ValueError('Compressed size mismatch')
        if self.offsets[0] != 0 or self.offsets != sorted(self.offsets):
            raise ValueError('Invalid offsets')

    def frame(self, index):
        x, y, w, h = self.rects[index]
        end = self.offsets[index + 1] if index + 1 < self.count else len(self.raw)
        data = self.raw[self.offsets[index]:end]
        pixels = bytearray()
        for a, r, g, b in struct.iter_unpack('4B', data):
            if a:
                pixels.extend((r, g, b, a))
            else:
                count = r | (g << 8) | (b << 16)
                if not count or len(pixels) + count * 4 > w * h * 4:
                    raise ValueError(f'Invalid transparent run in frame {index}')
                pixels.extend(bytes(count * 4))
        if len(pixels) != w * h * 4 or x + w > self.width or y + h > self.height:
            raise ValueError(f'Invalid frame {index}')
        image = Image.new('RGBA', (self.width, self.height))
        image.paste(Image.frombytes('RGBA', (w, h), bytes(pixels)), (x, y))
        return image

    def pack(self, images):
        prefix = bytearray(self.prefix)
        chunks, offset = [], 0
        for i, image in enumerate(images):
            image = image.convert('RGBA')
            if image.size != (self.width, self.height):
                raise ValueError(f'Canvas changed in frame {i}')
            x, y, w, h = self.rects[i]
            bounds = image.getbbox()
            if bounds and (bounds[0] < x or bounds[1] < y or bounds[2] > x + w or bounds[3] > y + h):
                raise ValueError(f'Nontransparent pixels outside original rectangle: frame {i}')
            struct.pack_into('<I', prefix, 1216 + i * 4, offset)
            end = self.offsets[i + 1] if i + 1 < self.count else len(self.raw)
            # Preserve original RLE encoding exactly for unchanged frames.
            if image.tobytes() == self.frame(i).tobytes():
                encoded = self.raw[self.offsets[i]:end]
            else:
                encoded = bytearray()
                pixels = list(image.crop((x, y, x + w, y + h)).getdata())
                # Encode transparent runs per scanline; retain original rect and order.
                for row in range(h):
                    col = 0
                    while col < w:
                        r, g, b, a = pixels[row * w + col]
                        if a:
                            encoded.extend((a, r, g, b)); col += 1
                        else:
                            start = col
                            while col < w and pixels[row * w + col][3] == 0:
                                col += 1
                            encoded.extend(struct.pack('<I', (col - start) << 8))
            chunks.append(encoded); offset += len(encoded)
        if len(chunks) != self.count:
            raise ValueError('Frame count changed')
        compressed = zlib.compress(b''.join(chunks), 9)
        struct.pack_into('<I', prefix, self.payload_at - 4, len(compressed))
        return bytes(prefix) + compressed


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=['extract', 'pack'])
    parser.add_argument('input', type=Path)
    parser.add_argument('directory', type=Path)
    parser.add_argument('output', nargs='?', type=Path)
    args = parser.parse_args()
    agf = AGF(args.input)
    if args.operation == 'extract':
        args.directory.mkdir(parents=True, exist_ok=True)
        for i in range(agf.count):
            agf.frame(i).save(args.directory / f'{i:03}.png')
        metadata = dict(source=args.input.name, sha256=hashlib.sha256(agf.blob).hexdigest(),
                        canvas=[agf.width, agf.height], count=agf.count, rectangles=agf.rects)
        (args.directory / 'metadata.json').write_text(json.dumps(metadata, indent=2))
    else:
        if not args.output or args.output.resolve() == args.input.resolve():
            parser.error('A separate output file is required; preserve original AGF')
        args.output.write_bytes(agf.pack([Image.open(args.directory / f'{i:03}.png') for i in range(agf.count)]))


if __name__ == '__main__':
    main()
